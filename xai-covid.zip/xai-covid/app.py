"""Clinical triage dashboard.  Run:  streamlit run app.py -- --weights runs/densenet121_clahe/model.pt"""
import sys
import numpy as np, torch, cv2, streamlit as st
from common import *

weights = sys.argv[sys.argv.index("--weights") + 1] if "--weights" in sys.argv else "runs/densenet121_clahe/model.pt"
st.set_page_config(page_title="Chest X-ray XAI Triage", layout="wide")


@st.cache_resource
def load():
    m, target = build_model("densenet121", pretrained=False)
    m.load_state_dict(torch.load(weights, map_location="cpu")); m.eval()
    return m, GradCAM(m, target)


model, cam = load()
st.title("Explainable COVID-19 / Pneumonia Triage")
st.caption("Research prototype - not for clinical diagnosis.")
up = st.file_uploader("Upload a chest X-ray (PNG/JPG)", type=["png", "jpg", "jpeg"])
if up:
    raw = cv2.imdecode(np.frombuffer(up.read(), np.uint8), cv2.IMREAD_GRAYSCALE)
    g = apply_clahe(cv2.resize(raw, (IMG_SIZE, IMG_SIZE), interpolation=cv2.INTER_AREA))
    img = np.stack([g] * 3, -1)
    m, k, p = cam(to_tensor(img), None)
    c1, c2, c3 = st.columns(3)
    c1.image(cv2.resize(raw, (IMG_SIZE, IMG_SIZE)), caption="Original", clamp=True)
    c2.image(img, caption="CLAHE-enhanced")
    c3.image(overlay(img, m), caption=f"Grad-CAM for '{CLASSES[k]}'")
    st.subheader(f"Prediction: {CLASSES[k]}  ({p[k]*100:.1f}% confidence)")
    st.bar_chart({c: float(v) for c, v in zip(CLASSES, p)})
    if p[k] < 0.7:
        st.warning("Low confidence - flag for radiologist review.")
