"""Shared utilities: CLAHE preprocessing, dataset, model builders, Grad-CAM."""
import cv2
import numpy as np
import torch
import torch.nn as nn
from torch.utils.data import Dataset
from torchvision import models, transforms

CLASSES = ["Normal", "Pneumonia", "COVID-19"]
IMG_SIZE = 224
MEAN, STD = [0.485, 0.456, 0.406], [0.229, 0.224, 0.225]


def apply_clahe(gray, clip_limit=2.0, tile=(8, 8)):
    """Contrast-Limited Adaptive Histogram Equalization on a uint8 grayscale image."""
    return cv2.createCLAHE(clipLimit=clip_limit, tileGridSize=tile).apply(gray)


def load_image(path, use_clahe=True, size=IMG_SIZE):
    gray = cv2.imread(str(path), cv2.IMREAD_GRAYSCALE)
    if gray is None:
        raise FileNotFoundError(path)
    gray = cv2.resize(gray, (size, size), interpolation=cv2.INTER_AREA)
    if use_clahe:
        gray = apply_clahe(gray)
    return np.stack([gray] * 3, axis=-1)  # HxWx3 uint8


class XrayDataset(Dataset):
    def __init__(self, df, root, train=False, use_clahe=True):
        self.df, self.root, self.use_clahe = df.reset_index(drop=True), root, use_clahe
        aug = [transforms.RandomRotation(10), transforms.RandomResizedCrop(IMG_SIZE, scale=(0.85, 1.0)),
               transforms.RandomHorizontalFlip(0.0)]  # no flips: laterality markers matter
        self.tf = transforms.Compose(
            ([transforms.ToPILImage()] + aug if train else [transforms.ToPILImage()])
            + [transforms.ToTensor(), transforms.Normalize(MEAN, STD)])

    def __len__(self):
        return len(self.df)

    def __getitem__(self, i):
        r = self.df.iloc[i]
        img = load_image(f"{self.root}/{r['file']}", self.use_clahe)
        return self.tf(img), int(r["label"])


def build_model(arch="densenet121", n_classes=3, pretrained=True):
    w = "DEFAULT" if pretrained else None
    if arch == "densenet121":
        m = models.densenet121(weights=w)
        m.classifier = nn.Sequential(nn.Dropout(0.3), nn.Linear(m.classifier.in_features, n_classes))
        target = m.features.denseblock4  # last dense block for Grad-CAM
    elif arch == "resnet50":
        m = models.resnet50(weights=w)
        m.fc = nn.Sequential(nn.Dropout(0.3), nn.Linear(m.fc.in_features, n_classes))
        target = m.layer4
    elif arch == "vgg16":
        m = models.vgg16(weights=w)
        m.classifier[6] = nn.Linear(4096, n_classes)
        target = m.features[-1]
    elif arch == "efficientnet_b0":
        m = models.efficientnet_b0(weights=w)
        m.classifier = nn.Sequential(nn.Dropout(0.3), nn.Linear(m.classifier[1].in_features, n_classes))
        target = m.features[-1]
    else:
        raise ValueError(arch)
    return m, target


def freeze_backbone(model, arch, freeze=True):
    head = {"densenet121": "classifier", "resnet50": "fc", "vgg16": "classifier",
            "efficientnet_b0": "classifier"}[arch]
    for n, p in model.named_parameters():
        p.requires_grad = (not freeze) or n.startswith(head)


class GradCAM:
    """Grad-CAM (Selvaraju et al., 2017) on a chosen conv block."""

    def __init__(self, model, target_layer):
        self.model, self.acts, self.grads = model, None, None
        target_layer.register_forward_hook(self._fwd)
        target_layer.register_full_backward_hook(self._bwd)

    def _fwd(self, m, i, o):
        self.acts = o.detach()

    def _bwd(self, m, gi, go):
        self.grads = go[0].detach()

    def __call__(self, x, class_idx=None):
        self.model.eval()
        x = x.clone().requires_grad_(True)  # ensures backward hooks fire even with frozen weights
        logits = self.model(x)
        probs = torch.softmax(logits, 1)
        class_idx = int(probs.argmax(1)) if class_idx is None else class_idx
        self.model.zero_grad()
        logits[0, class_idx].backward()
        w = self.grads.mean(dim=(2, 3), keepdim=True)
        cam = torch.relu((w * self.acts).sum(1))[0].cpu().numpy()
        cam = cv2.resize(cam, (IMG_SIZE, IMG_SIZE))
        cam = (cam - cam.min()) / (cam.max() - cam.min() + 1e-8)
        return cam, class_idx, probs[0].detach().cpu().numpy()


def overlay(img_rgb, cam, alpha=0.4):
    heat = cv2.applyColorMap((cam * 255).astype(np.uint8), cv2.COLORMAP_JET)[:, :, ::-1]
    return (alpha * heat + (1 - alpha) * img_rgb).astype(np.uint8)


def to_tensor(img_rgb):
    tf = transforms.Compose([transforms.ToPILImage(), transforms.ToTensor(), transforms.Normalize(MEAN, STD)])
    return tf(img_rgb).unsqueeze(0)
