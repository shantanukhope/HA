# Explainable AI Framework for COVID-19 and Pneumonia Detection in Chest X-Rays

Pipeline: **CLAHE** contrast enhancement → **DenseNet121** (ImageNet transfer learning) → **Grad-CAM** heatmaps → **Streamlit** triage dashboard.
Three classes: Normal, Pneumonia (viral/bacterial/fungal), COVID-19. Dataset: [V7 Labs COVID-19 X-Ray Dataset](https://github.com/v7labs/covid-19-xray-dataset).

> Research prototype only - not for clinical diagnosis.

## Setup
```bash
pip install -r requirements.txt
git clone --depth 1 https://github.com/v7labs/covid-19-xray-dataset
python prepare_dataset.py --annotations covid-19-xray-dataset/annotations/all-images.zip --out data
```
`prepare_dataset.py` prints the annotation tag counts - check the label mapping looks right.
If image links have expired: `pip install darwin-py && darwin dataset pull v7-labs/covid-19-chest-x-ray-dataset:all-images`, then pass `--images_dir <folder>`.

## Train and evaluate
```bash
python train.py --arch densenet121 --out runs/densenet121_clahe          # proposed model
python train.py --arch densenet121 --no_clahe --out runs/densenet121_noclahe   # CLAHE ablation
python train.py --arch resnet50 --out runs/resnet50                      # baselines
python train.py --arch vgg16 --out runs/vgg16
python train.py --arch efficientnet_b0 --out runs/efficientnet_b0
```
Each run writes `metrics.json`, `history.csv`, `curves.png`, `confusion.png`, `roc.png`, `gradcam_gallery.png`, `model.pt`.

## Dashboard
```bash
streamlit run app.py -- --weights runs/densenet121_clahe/model.pt
```

## Files
`common.py` (CLAHE, dataset, models, Grad-CAM) · `prepare_dataset.py` · `train.py` · `app.py`
