"""Train / evaluate a chest X-ray classifier (Normal / Pneumonia / COVID-19) and export results.

Example:
  python train.py --data data --arch densenet121 --epochs 12 --out runs/densenet121_clahe
  python train.py --data data --arch densenet121 --no_clahe --out runs/densenet121_noclahe   # ablation
  python train.py --data data --arch resnet50 --out runs/resnet50                            # baselines
"""
import argparse, json, os, time
import numpy as np, pandas as pd, torch, torch.nn as nn
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.metrics import (accuracy_score, precision_recall_fscore_support, confusion_matrix,
                             roc_auc_score, roc_curve, classification_report)
from torch.utils.data import DataLoader, WeightedRandomSampler
from common import *


def run_epoch(model, loader, crit, dev, opt=None):
    train = opt is not None
    model.train(train)
    tot, correct, n = 0.0, 0, 0
    with torch.set_grad_enabled(train):
        for x, y in loader:
            x, y = x.to(dev), y.to(dev)
            out = model(x)
            loss = crit(out, y)
            if train:
                opt.zero_grad(); loss.backward(); opt.step()
            tot += loss.item() * len(y); correct += (out.argmax(1) == y).sum().item(); n += len(y)
    return tot / n, correct / n


@torch.no_grad()
def predict(model, loader, dev):
    model.eval(); P, Y = [], []
    for x, y in loader:
        P.append(torch.softmax(model(x.to(dev)), 1).cpu().numpy()); Y.append(y.numpy())
    return np.concatenate(P), np.concatenate(Y)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", default="data"); ap.add_argument("--out", default="runs/run")
    ap.add_argument("--arch", default="densenet121")
    ap.add_argument("--epochs", type=int, default=12); ap.add_argument("--warmup", type=int, default=2,
                    help="epochs with frozen backbone before full fine-tuning")
    ap.add_argument("--bs", type=int, default=32); ap.add_argument("--lr", type=float, default=1e-3)
    ap.add_argument("--ft_lr", type=float, default=1e-4); ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--no_clahe", action="store_true"); ap.add_argument("--workers", type=int, default=2)
    ap.add_argument("--max_per_class", type=int, default=0, help="optional cap on Normal/Pneumonia for speed")
    a = ap.parse_args()
    os.makedirs(a.out, exist_ok=True)
    torch.manual_seed(a.seed); np.random.seed(a.seed)
    dev = "cuda" if torch.cuda.is_available() else "cpu"

    df = pd.read_csv(f"{a.data}/labels.csv")
    if a.max_per_class:
        df = pd.concat([g.sample(min(len(g), a.max_per_class), random_state=a.seed) if l < 2 else g
                        for l, g in df.groupby("label")])
    tr, tmp = train_test_split(df, test_size=0.30, stratify=df["label"], random_state=a.seed)
    va, te = train_test_split(tmp, test_size=0.50, stratify=tmp["label"], random_state=a.seed)
    split_sizes = {"train": len(tr), "val": len(va), "test": len(te)}
    print(split_sizes, dev)

    use_clahe = not a.no_clahe
    mk = lambda d, t: XrayDataset(d, a.data, train=t, use_clahe=use_clahe)
    cnt = tr["label"].value_counts().sort_index().values
    cw = torch.tensor(cnt.sum() / (len(cnt) * cnt), dtype=torch.float32).to(dev)
    sw = tr["label"].map(lambda l: 1.0 / cnt[l]).values
    sampler = WeightedRandomSampler(sw, len(tr), replacement=True)
    dl_tr = DataLoader(mk(tr, True), a.bs, sampler=sampler, num_workers=a.workers)
    dl_va = DataLoader(mk(va, False), a.bs, num_workers=a.workers)
    dl_te = DataLoader(mk(te, False), a.bs, num_workers=a.workers)

    model, target = build_model(a.arch); model.to(dev)
    crit = nn.CrossEntropyLoss(weight=cw)
    hist, best, best_sd, t0 = [], 0.0, None, time.time()
    for ep in range(a.epochs):
        warm = ep < a.warmup
        freeze_backbone(model, a.arch, warm)
        opt = torch.optim.Adam([p for p in model.parameters() if p.requires_grad], lr=a.lr if warm else a.ft_lr)
        trl, tra = run_epoch(model, dl_tr, crit, dev, opt)
        val, vaa = run_epoch(model, dl_va, crit, dev)
        hist.append(dict(epoch=ep + 1, train_loss=trl, train_acc=tra, val_loss=val, val_acc=vaa))
        print(f"ep{ep+1:02d} train {trl:.3f}/{tra:.3f}  val {val:.3f}/{vaa:.3f}", flush=True)
        if vaa >= best:
            best, best_sd = vaa, {k: v.detach().cpu().clone() for k, v in model.state_dict().items()}
    train_minutes = (time.time() - t0) / 60
    model.load_state_dict(best_sd)
    torch.save(best_sd, f"{a.out}/model.pt")

    P, Y = predict(model, dl_te, dev); pred = P.argmax(1)
    pr, rc, f1, _ = precision_recall_fscore_support(Y, pred, average="macro", zero_division=0)
    auc = roc_auc_score(Y, P, multi_class="ovr", average="macro")
    cm = confusion_matrix(Y, pred, labels=[0, 1, 2])
    per_class = classification_report(Y, pred, target_names=CLASSES, output_dict=True, zero_division=0)
    res = dict(arch=a.arch, clahe=use_clahe, accuracy=accuracy_score(Y, pred), precision_macro=pr,
               recall_macro=rc, f1_macro=f1, auc_macro_ovr=auc, confusion_matrix=cm.tolist(),
               per_class={c: per_class[c] for c in CLASSES}, best_val_acc=best, split=split_sizes,
               class_counts_train=cnt.tolist(), train_minutes=train_minutes, device=dev,
               hyperparameters=dict(epochs=a.epochs, warmup=a.warmup, batch=a.bs, lr_head=a.lr,
                                    lr_finetune=a.ft_lr, optimizer="Adam", img=IMG_SIZE, seed=a.seed,
                                    loss="weighted cross-entropy", sampler="class-balanced"))
    json.dump(res, open(f"{a.out}/metrics.json", "w"), indent=2)
    pd.DataFrame(hist).to_csv(f"{a.out}/history.csv", index=False)

    # ---- figures
    h = pd.DataFrame(hist)
    fig, ax = plt.subplots(1, 2, figsize=(9, 3.2))
    ax[0].plot(h.epoch, h.train_loss, label="train"); ax[0].plot(h.epoch, h.val_loss, label="val"); ax[0].set_title("Loss")
    ax[1].plot(h.epoch, h.train_acc, label="train"); ax[1].plot(h.epoch, h.val_acc, label="val"); ax[1].set_title("Accuracy")
    for x in ax: x.set_xlabel("Epoch"); x.legend()
    plt.tight_layout(); plt.savefig(f"{a.out}/curves.png", dpi=200); plt.close()

    fig, ax = plt.subplots(figsize=(4, 3.6)); ax.imshow(cm, cmap="Blues")
    ax.set_xticks(range(3)); ax.set_yticks(range(3)); ax.set_xticklabels(CLASSES, rotation=30); ax.set_yticklabels(CLASSES)
    for i in range(3):
        for j in range(3): ax.text(j, i, cm[i, j], ha="center", va="center", color="black" if cm[i, j] < cm.max() / 2 else "white")
    ax.set_xlabel("Predicted"); ax.set_ylabel("True"); plt.tight_layout(); plt.savefig(f"{a.out}/confusion.png", dpi=200); plt.close()

    fig, ax = plt.subplots(figsize=(4, 3.6))
    for k, c in enumerate(CLASSES):
        fpr, tpr, _ = roc_curve((Y == k).astype(int), P[:, k]); ax.plot(fpr, tpr, label=c)
    ax.plot([0, 1], [0, 1], "k--", lw=0.8); ax.set_xlabel("FPR"); ax.set_ylabel("TPR"); ax.legend()
    plt.tight_layout(); plt.savefig(f"{a.out}/roc.png", dpi=200); plt.close()

    # ---- Grad-CAM gallery: 3 correctly classified test images per class
    cam = GradCAM(model, target); te = te.reset_index(drop=True)
    fig, ax = plt.subplots(3, 6, figsize=(12, 6.2)); ax = np.atleast_2d(ax)
    for k in range(3):
        idx = [i for i in range(len(te)) if te.label[i] == k and pred[i] == k][:3]
        for s, i in enumerate(idx):
            img = load_image(f"{a.data}/{te.file[i]}", use_clahe)
            m, _, _ = cam(to_tensor(img).to(dev), k)
            ax[k, 2 * s].imshow(img); ax[k, 2 * s + 1].imshow(overlay(img, m))
            ax[k, 2 * s].set_title(f"{CLASSES[k]}", fontsize=8); ax[k, 2 * s + 1].set_title("Grad-CAM", fontsize=8)
    for x in ax.ravel(): x.axis("off")
    plt.tight_layout(); plt.savefig(f"{a.out}/gradcam_gallery.png", dpi=200); plt.close()
    print(json.dumps({k: res[k] for k in ["accuracy", "precision_macro", "recall_macro", "f1_macro", "auc_macro_ovr"]}, indent=2))


if __name__ == "__main__":
    main()
