"""Build a labelled image folder + labels.csv from the V7 COVID-19 X-ray annotations.

Usage:
  git clone --depth 1 https://github.com/v7labs/covid-19-xray-dataset
  python prepare_dataset.py --annotations covid-19-xray-dataset/annotations/all-images.zip --out data

The repo only stores annotations; each JSON holds a download URL for the image.
If the URLs have expired, pull images with darwin-py instead (see README) and
re-run with --images_dir pointing at them (files must be named <image filename> from the JSON).
"""
import argparse, io, json, os, sys, zipfile, time
from concurrent.futures import ThreadPoolExecutor
from collections import Counter
import pandas as pd
import requests


def label_from_tags(names):
    low = [n.lower() for n in names if n.lower() != "lung"]
    if any("covid" in n for n in low):
        return 2
    if any("pneumonia" in n and not n.startswith("no pneumonia") for n in low):
        return 1
    if any("no pneumonia" in n or "healthy" in n for n in low):
        return 0
    return None


def fetch(args):
    url, dst, tries = args
    if os.path.exists(dst) and os.path.getsize(dst) > 0:
        return True
    for k in range(tries):
        try:
            r = requests.get(url, timeout=30)
            if r.status_code == 200 and r.content:
                with open(dst, "wb") as f:
                    f.write(r.content)
                return True
        except requests.RequestException:
            pass
        time.sleep(1 + k)
    return False


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--annotations", required=True)
    ap.add_argument("--out", default="data")
    ap.add_argument("--images_dir", default=None, help="use already-downloaded images instead of URLs")
    ap.add_argument("--workers", type=int, default=16)
    a = ap.parse_args()

    img_out = os.path.join(a.out, "images")
    os.makedirs(img_out, exist_ok=True)
    rows, tagcount, jobs = [], Counter(), []
    with zipfile.ZipFile(a.annotations) as z:
        for n in z.namelist():
            if not n.endswith(".json"):
                continue
            d = json.load(io.TextIOWrapper(z.open(n), encoding="utf-8"))
            names = [x["name"] for x in d.get("annotations", [])]
            tagcount.update(set(names))
            if any(n in ("CT", "Ignore") or n.startswith(("View/Axial", "View/Coronal", "View/Lateral"))
                   for n in names):
                continue  # drop CT slices, lateral views and images flagged "Ignore"
            lab = label_from_tags(names)
            if lab is None:
                continue
            fn = d["image"]["filename"]
            rows.append({"file": f"images/{fn}", "label": lab, "orig": d["image"].get("original_filename", "")})
            if a.images_dir is None:
                jobs.append((d["image"]["url"], os.path.join(img_out, fn), 3))

    print("Tag counts in annotations (verify the label mapping!):")
    for k, v in tagcount.most_common():
        print(f"  {k}: {v}")

    if a.images_dir is None:
        with ThreadPoolExecutor(a.workers) as ex:
            ok = list(ex.map(fetch, jobs))
        print(f"Downloaded {sum(ok)}/{len(ok)} images")
        if sum(ok) == 0:
            sys.exit("No images could be downloaded - use darwin-py (see README) and pass --images_dir.")
        good = {j[1] for j, k in zip(jobs, ok) if k}
        rows = [r for r in rows if os.path.join(a.out, r["file"]) in good]
    else:
        rows = [r for r in rows if os.path.exists(os.path.join(a.images_dir, os.path.basename(r["file"])))]
        for r in rows:
            dst = os.path.join(a.out, r["file"])
            if not os.path.exists(dst):
                os.symlink(os.path.abspath(os.path.join(a.images_dir, os.path.basename(r["file"]))), dst)

    df = pd.DataFrame(rows)
    df.to_csv(os.path.join(a.out, "labels.csv"), index=False)
    print(df["label"].map({0: "Normal", 1: "Pneumonia", 2: "COVID-19"}).value_counts())


if __name__ == "__main__":
    main()
